import FormularioCadastro from "./components/FormularioCadastro";  // importando função

function App() {                                                   // função principal 
  return (                                                         // retorna o que será exibido na tela 
    <div>                                                          
      <FormularioCadastro />                                       
    </div>                                                         // chamando componente formulario que contem email, senha, nome e botao 
  );
}

export default App;
