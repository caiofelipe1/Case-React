import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";     // aqui importei as bibliotecas
import * as yup from "yup";

// Regras de validação 
const schema = yup.object().shape({                        // defini um esquema de validação para as especificações usando yup.
    nome: yup.string().required("Nome é obrigatório"),
    email: yup.string().email("E-mail inválido").required("E-mail é obrigatório"),
    senha: yup.string().min(8, "A senha deve ter no mínimo 8 caracteres").required("Senha é obrigatória"),
});

export default function FormularioCadastro() {             // função para o formulário
    const {
        register,                                          // registra os campos do formulário para que o React Hook Form possa monitorá-los e validar os dados.
        handleSubmit,                                      // função usada para lidar com o envio do formulário. Ela recebe a função onSubmit e a chama quando o formulário é válido.
        formState: { errors },                             // acessa o estado do formulário, especialmente os erros de validação, se houverem.
    } = useForm({                                          // usa o React Hook Form para criar e gerenciar o formulário
        resolver: yupResolver(schema),                     // conexão do React Hook com validação do yup
    });

    
    const onSubmit = (data) => {                           // função está sendo chamada ao enviar o formulário e é válida
        console.log("Dados cadastrados:", data);           // data: Os dados do formulário que o usuário preencheu são passados como argumento para a função e exibe esses dados no console.
    };

    return (                                               // estilização
        <div style={{ 
            display: "flex", 
            justifyContent: "center", 
            alignItems: "center", 
            height: "100vh", 
            width: "100vw"
        }}>
            <form 
                onSubmit={handleSubmit(onSubmit)} 
                style={{ 
                    display: "flex", 
                    flexDirection: "column", 
                    width: "300px",                         
                    gap: "10px" 
                }}
            >
                <label>Nome:</label>
                <input type="text" {...register("nome")} />
                <p style={{ color: "red" }}>{errors.nome?.message}</p>

                <label>E-mail:</label>
                <input type="email" {...register("email")} />
                <p style={{ color: "red" }}>{errors.email?.message}</p>

                <label>Senha:</label>
                <input type="password" {...register("senha")} />
                <p style={{ color: "red" }}>{errors.senha?.message}</p>

                <button type="submit">Enviar</button>
            </form>
        </div>
    );
}
